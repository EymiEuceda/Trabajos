﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PM2Ejer1_2.Models
{
    class Contactos
    {
        public String Nombre { get; set; }
        public String Apellidos { get; set; }
        public Int32 Edad { get; set; }
        public String Email { get; set; }
    }
}
